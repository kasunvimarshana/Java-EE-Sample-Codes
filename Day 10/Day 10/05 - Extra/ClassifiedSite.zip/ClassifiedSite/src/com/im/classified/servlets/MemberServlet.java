package com.im.classified.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.im.classified.Member;
import com.im.classified.db.DB;

@WebServlet("/register")
public class MemberServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		Member member = new Member();
		member.setName(req.getParameter("name"));
		member.setEmail(req.getParameter("email"));
		member.setPhone(req.getParameter("phone"));
		member.setPassword(req.getParameter("password"));
		member.setRegistered(new Date());
		
		DB.insert(member);
		
		resp.getWriter().print( "<h1>Thank you for Registering with Us ! </h1> <a href=\'index.jsp\'>Home</a>");
		
	}
}
