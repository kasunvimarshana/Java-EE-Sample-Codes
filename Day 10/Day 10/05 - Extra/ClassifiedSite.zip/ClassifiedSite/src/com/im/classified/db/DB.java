package com.im.classified.db;


import java.util.List;




import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class DB {

	static Session session;
	
	static {
		Configuration config = new Configuration();
		
	    config.configure("hibernate.cfg.xml");

//	    ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(
//	            config.getProperties()).build();
//	    SessionFactory sf = config.buildSessionFactory(serviceRegistry);
		
		SessionFactory sf = config.buildSessionFactory();
		session = sf.openSession();
		
	}
	
	public static void insert(Object obj){
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(obj);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if(transaction!=null){
				transaction.rollback();
			}
		}
		
	}
	
	public static void update(Object obj){
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.update(obj);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if(transaction!=null){
				transaction.rollback();
			}
		}
		
	}
	
	public static List list(String entityName){
		List list = null;
		Transaction transaction = null;
		try {
			
			transaction = session.beginTransaction();
			list = session.createQuery("from "+entityName).list();

			transaction.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			if(transaction!=null){
				transaction.rollback();
			}
		}
		return list;
	}
	
	public static Object get(Class cls, int id){
		Object obj=null;
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			obj = session.get(cls, id);

			transaction.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			if(transaction!=null){
				transaction.rollback();
			}
		}
		return obj;
	}
	
}
