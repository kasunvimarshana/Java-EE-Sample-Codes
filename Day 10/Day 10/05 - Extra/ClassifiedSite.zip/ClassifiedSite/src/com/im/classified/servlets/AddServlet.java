package com.im.classified.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.startup.Catalina;

import com.im.classified.Add;
import com.im.classified.Category;
import com.im.classified.Member;
import com.im.classified.db.DB;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Add add = new Add();
		add.setTitle(req.getParameter("title"));
		add.setDescription(req.getParameter("description"));
		int cid = Integer.parseInt(req.getParameter("category"));
		add.setCategory((Category)DB.get(Category.class, cid));
		
		DB.insert(add);
		
		resp.getWriter().print( "<h1>Thank you for Registering with Us ! </h1> <a href=\'index.jsp\'>Home</a>");
		
	}

}
